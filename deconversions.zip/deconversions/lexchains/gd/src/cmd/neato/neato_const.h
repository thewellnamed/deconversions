/*
 * Copyright (c) AT&T Corp. 1994, 1995.
 * This code is licensed by AT&T Corp.  For the
 * terms and conditions of the license, see
 * http://www.research.att.com/orgs/ssr/book/reuse
 */

#define NDIM			2
#define Spring_coeff	1.0

#define MAXFILES		64
#define MYHUGE			(1.0e+37)
