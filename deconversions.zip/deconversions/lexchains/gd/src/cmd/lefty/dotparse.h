
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
    long i;
    char *s;
    void *o;
} YYSTYPE;
extern YYSTYPE yylval;
# define T_graph 257
# define T_digraph 258
# define T_subgraph 259
# define T_strict 260
# define T_node 261
# define T_edge 262
# define T_edgeop 263
# define T_id 264
